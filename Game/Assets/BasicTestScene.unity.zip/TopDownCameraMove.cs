using UnityEngine;
using System.Collections;

public class TopDownCameraMove : MonoBehaviour {
    public float sensitivity;
	public int margin;
	public int heightAbove;
	public int distanceBehind;
	void Awake () {
		GameObject player = GameObject.Find("Player");
		Vector3 playerPos = player.transform.position;

		this.gameObject.transform.eulerAngles = new Vector3(0f,0f,0f);
		this.gameObject.transform.position = new Vector3(playerPos.x,playerPos.y+heightAbove,playerPos.z-distanceBehind);

		GameObject camera = GameObject.Find("MainCameraPlane/Main Camera");
		Transform cameraPos = camera.transform;

		cameraPos.position = new Vector3(playerPos.x,playerPos.y+heightAbove,playerPos.z-distanceBehind);
		//cameraPos.eulerAngles = new Vector3(100f,0f,0f);
		cameraPos.LookAt(player.transform);


	}
	void Update(){
		Vector3 mousePos = Input.mousePosition;
		Transform gameTransform = this.gameObject.transform;
		
		
		if(mousePos.x >= Screen.width-margin && mousePos.y >= Screen.height-margin){
			gameTransform.Translate(new Vector3(sensitivity,0f,sensitivity));
		}
		
		else if(mousePos.x <= margin && mousePos.y <= margin){
			gameTransform.Translate(new Vector3(-sensitivity,0f,-sensitivity));	
		}
		
		else if(mousePos.x <= margin && mousePos.y >= Screen.height-margin){
			gameTransform.Translate(new Vector3(-sensitivity,0f,sensitivity));	
		}
		
		else if(mousePos.x >= Screen.width-margin && mousePos.y <= margin){
			gameTransform.Translate(new Vector3(sensitivity,0f,-sensitivity));
		}
		else if(mousePos.x >= Screen.width-margin){
		gameTransform.Translate(new Vector3(sensitivity,0f,0f));
        }
	
	    else if(mousePos.x <= margin){
		gameTransform.Translate(new Vector3(-sensitivity,0f,0f));
        }
		
		else if(mousePos.y >= Screen.height-margin){
			gameTransform.Translate(new Vector3(0f,0f,sensitivity));
		}
		
		else if(mousePos.y <= margin){
			gameTransform.Translate (new Vector3(0f,0f,-sensitivity));
		}
		
    }
}
